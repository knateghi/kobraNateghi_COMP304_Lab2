package com.example.customelist;

public class Book {
    private  int b_Cover;
    private String b_Title;
    private  String b_publishDAte;
    private String b_isbn;

    public Book(int b_Cover, String b_Title, String b_publishDAte, String b_isbn) {
        this.b_Cover = b_Cover;
        this.b_Title = b_Title;
        this.b_publishDAte = b_publishDAte;
        this.b_isbn = b_isbn;
    }

    public int getB_Cover() {
        return b_Cover;
    }

    public void setB_Cover(int b_Cover) {
        this.b_Cover = b_Cover;
    }

    public String getB_Title() {
        return b_Title;
    }

    public void setB_Title(String b_Title) {
        this.b_Title = b_Title;
    }

    public String getB_publishDAte() {
        return b_publishDAte;
    }

    public void setB_publishDAte(String b_publishDAte) {
        this.b_publishDAte = b_publishDAte;
    }

    public String getB_isbn() {
        return b_isbn;
    }

    public void setB_isbn(String b_isbn) {
        this.b_isbn = b_isbn;
    }
}
