package com.example.customelist;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView booksList;
    BookAdapter bookAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
       booksList = (ListView)findViewById( R.id.listView );

        ArrayList<Book> bookArrayList = new ArrayList<>(  );
        bookArrayList.add(new Book( R.drawable.rxjava, "RX Java For Android Developers", "2017", "null" ));
        bookArrayList.add(new Book( R.drawable.cookbook, "Android Developer Cookbook", "2016", "null" ));
        bookArrayList.add(new Book( R.drawable.dummies, "Android Tabliets for Dummies ", "2018", "null" ));
        bookArrayList.add(new Book( R.drawable.xamarin, "Xamarin Mobile Application for Android", "2017", "null" ));
        bookArrayList.add(new Book( R.drawable.kotlin, "Learn Kotlin for Android Developerment", "2017", "null" ));



        bookAdapter = new BookAdapter( this,bookArrayList );
        booksList.setAdapter( bookAdapter );


       booksList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

           @Override
           public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


               //Toast.makeText(MainActivity.this, "You click the list", Toast.LENGTH_SHORT).show();
               /* you can you if statement or switch case
               if(position==0) {
                   Toast.makeText(MainActivity.this, position + " RX Java For Android ", Toast.LENGTH_SHORT).show();
               }
               if (position==1) {
                   Toast.makeText(MainActivity.this, position + " Android cook book", Toast.LENGTH_SHORT).show();
               }
               if (position==2) {
                   Toast.makeText(MainActivity.this, position + " Android Tablet", Toast.LENGTH_SHORT).show();
               }
               if (position==3) {
                   Toast.makeText(MainActivity.this, position + " Xamarin Mobile Application", Toast.LENGTH_SHORT).show();
               }
               if (position==4) {
                   Toast.makeText(MainActivity.this, position + " Learn Kotlin for Mobile ", Toast.LENGTH_SHORT).show();
               }
               if (position==5) {
                   Toast.makeText(MainActivity.this, position + " Android cook book", Toast.LENGTH_SHORT).show();
               }

                */


               switch (position){
                   case 0:
                       Toast.makeText(MainActivity.this, position + " RX Java For Android ", Toast.LENGTH_SHORT).show();
                       //here you can jump to another activity using intent or using SharedPreferences to save data in local memeory
                       break;
                   case 1:
                       Toast.makeText(MainActivity.this, position + " Android cook book", Toast.LENGTH_SHORT).show();
                       break;
                   case 2:
                       Toast.makeText(MainActivity.this, position + " Android Tablet", Toast.LENGTH_SHORT).show();
                       break;
                   case 3:
                       Toast.makeText(MainActivity.this, position + " Xamarin Mobile Application", Toast.LENGTH_SHORT).show();
                       break;
                   case 4:
                       Toast.makeText(MainActivity.this, position + " Learn Kotlin for Mobile ", Toast.LENGTH_SHORT).show();
                   case 5:
                       Toast.makeText(MainActivity.this, position + " Android cook book", Toast.LENGTH_SHORT).show();
                       break;
                   default:
                           Toast.makeText(MainActivity.this, "See you soon", Toast.LENGTH_SHORT).show();
               }

           }
       });

    }
}
