package com.example.customelist;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class BookAdapter  extends ArrayAdapter <Book>{

    private Context b_Context;
    private List<Book> bookList = new ArrayList<>(  );

    public BookAdapter(@NonNull Context context, @SuppressLint("SupportAnnotationUsage") @LayoutRes ArrayList<Book> list){
        super(context, 0 , list);
        b_Context = context;
        bookList = list;

    }




    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if (listItem==null){
            listItem= LayoutInflater.from( b_Context ).inflate( R.layout.list_item,parent,false );
        }


        Book selectedBook=bookList.get( position );
        ImageView imageView = (ImageView)listItem.findViewById( R.id.image_View_list );
        imageView.setImageResource( selectedBook.getB_Cover() );
        // image.setImageResource(currentMovie.getmImageDrawable());

        TextView textViewTitle =(TextView)listItem.findViewById( R.id.textView_opt1 );
        textViewTitle.setText( selectedBook.getB_Title() );
        TextView textViewIsbn = (TextView)listItem.findViewById( R.id.textView_opt2 );
        textViewIsbn .setText( selectedBook.getB_isbn() );
        TextView textViewPublish = (TextView)listItem.findViewById( R.id.textView_opt3);
        textViewPublish .setText( selectedBook.getB_publishDAte() );

        return listItem;


    }
}
